knitr::opts_chunk$set(echo = TRUE)

setwd("/home/sthu/Dropbox/hsf/exams/22-07/scr/")

rm(list=ls())

# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("sjPlot")
library("tidyverse")
library("ggpubr")
library("sjPlot")

load(url("https://github.com/hubchev/courses/raw/main/dta/forest.Rdata"))

head(df)

tail(df)

 # panel data set
 # date and country.x

dim(df)

summary(df)

df <- rename(df, country=country.x)

df <- rename(df, year=date)

df <- df %>% 
  mutate(gdp_pc = gdp/pop)

df  %>%
  group_by(income) %>%
  summarise(m_gdp_pc = mean(gdp_pc, na.rm = TRUE), 
            m_unemployment = mean(unemployment, na.rm = TRUE)
  )

df  %>%
  group_by(income) %>%
  filter(year==2020) %>% 
  summarise(mean(gdp_pc, na.rm = TRUE), 
            mean(gdp_growth, na.rm = TRUE), 
            mean(unemployment), 
            mean(unemployment_dif, na.rm = TRUE), 
  )

df %>% 
  select( gdp, gdp_pc, gdp_growth, unemployment, unemployment_dif) %>% 
  plot()

df %>% 
  filter(year == 2015) %>% 
  select( gdp, gdp_pc, gdp_growth, unemployment, unemployment_dif) %>% 
  plot()

cor(df$unemployment_dif, df$gdp_growth, method = c("pearson"))

ggplot(df, aes(x = gdp_growth, y = unemployment_dif)) +
  geom_point() +
  stat_smooth(formula=y~x, method="lm", se=FALSE) 

p1 <- df %>% 
  filter(income == "High income") %>% 
  ggplot(aes(x = gdp_growth, y = unemployment_dif)) +
  geom_point() +
  stat_smooth(formula=y~x, method="lm", se=FALSE) +
  ggtitle("High income")

p2 <- df %>% 
  filter(income == "Low income") %>% 
  ggplot(aes(x = gdp_growth, y = unemployment_dif)) +
  geom_point() +
  stat_smooth(formula=y~x, method="lm", se=FALSE) +
  ggtitle("Low income")

ggarrange(p1, p2, 
          labels = c("A", "B", "C"),
          ncol = 2, nrow = 1)

m1  <-  lm(unemployment_dif ~ gdp_growth, data = df)

m2  <-  df %>% 
  filter(income == "High income") %>% 
  lm(unemployment_dif ~ gdp_growth, data = .)

m3  <-  df %>% 
  filter(income == "Low income") %>% 
  lm(unemployment_dif ~ gdp_growth, data = .)

summary(m1)
summary(m2)
summary(m3)

tab_model(m1, m2, m3,
          # file="reg_output.html",
          p.style = "stars",
          p.threshold = c(0.2, 0.1, 0.05),
          show.ci = FALSE, 
          show.se = FALSE, 
          show.aic = TRUE,
          dv.labels = c("World", "High income", "Low income")) 

htmltools::includeHTML("reg_output.html")

## wkhtmltopdf -s A6 reg_output.html reg_output.pdf


# rmarkdown::render("22-07_dsda_exam.Rmd", "all")

# knitr::purl(input = "22-07_dsda_exam.Rmd", output = "22-07_dsda_solution.R",documentation = 0)
